-- ================================================================
-- Student Management System - COMPLETE DATABASE SETUP
-- HOW TO USE:
--   1. Open SQL Server Management Studio (SSMS)
--   2. Connect to your server
--   3. Click "New Query"
--   4. Paste this entire script
--   5. Press F5 to run
--   6. After running: Right-click DB > Tasks > Back Up
--      to get your own .bak file
-- ================================================================

USE master;
GO

-- Drop if exists and recreate
IF EXISTS (SELECT name FROM sys.databases WHERE name = N'StudentManagementDB')
BEGIN
    ALTER DATABASE StudentManagementDB SET SINGLE_USER WITH ROLLBACK IMMEDIATE;
    DROP DATABASE StudentManagementDB;
END
GO

CREATE DATABASE StudentManagementDB;
GO

USE StudentManagementDB;
GO

-- ================================================================
-- TABLE: Users
-- ================================================================
CREATE TABLE Users (
    UserID    INT IDENTITY(1,1) PRIMARY KEY,
    Username  NVARCHAR(50)  NOT NULL UNIQUE,
    Password  NVARCHAR(100) NOT NULL,
    Email     NVARCHAR(100) NULL,
    CreatedAt DATETIME      DEFAULT GETDATE()
);
GO

-- ================================================================
-- TABLE: Students
-- ================================================================
CREATE TABLE Students (
    StudentID    INT IDENTITY(1,1) PRIMARY KEY,
    StudentName  NVARCHAR(100) NOT NULL,
    EnrollmentNo NVARCHAR(20)  NOT NULL UNIQUE,
    Branch       NVARCHAR(50)  NULL,
    Semester     NVARCHAR(5)   NULL,
    Gender       NVARCHAR(10)  NULL,
    ContactNo    NVARCHAR(15)  NULL,
    Email        NVARCHAR(100) NULL,
    CreatedAt    DATETIME      DEFAULT GETDATE()
);
GO

-- ================================================================
-- TABLE: CIAMarks
-- ================================================================
CREATE TABLE CIAMarks (
    MarkID       INT IDENTITY(1,1) PRIMARY KEY,
    StudentID    INT            NOT NULL,
    StudentName  NVARCHAR(100)  NULL,
    EnrollmentNo NVARCHAR(20)   NULL,
    Subject      NVARCHAR(100)  NOT NULL,
    CIA1         DECIMAL(5,2)   DEFAULT 0,
    CIA2         DECIMAL(5,2)   DEFAULT 0,
    CIA3         DECIMAL(5,2)   DEFAULT 0,
    Remarks      NVARCHAR(200)  NULL,
    EnteredAt    DATETIME       DEFAULT GETDATE(),
    CONSTRAINT FK_CIAMarks_Students
        FOREIGN KEY (StudentID) REFERENCES Students(StudentID)
);
GO

-- ================================================================
-- TRIGGER: Auto fill StudentName & EnrollmentNo in CIAMarks
-- ================================================================
CREATE TRIGGER trg_InsertCIAMarks
ON CIAMarks
AFTER INSERT
AS
BEGIN
    SET NOCOUNT ON;
    UPDATE m
    SET    m.StudentName   = s.StudentName,
           m.EnrollmentNo  = s.EnrollmentNo
    FROM   CIAMarks m
    INNER JOIN inserted  i ON m.MarkID    = i.MarkID
    INNER JOIN Students  s ON i.StudentID = s.StudentID;
END;
GO

-- ================================================================
-- VIEW: Leaderboard
-- ================================================================
CREATE VIEW View_Leaderboard AS
SELECT
    ROW_NUMBER() OVER (
        ORDER BY SUM(ISNULL(m.CIA1,0)+ISNULL(m.CIA2,0)+ISNULL(m.CIA3,0)) DESC
    ) AS Rank,
    s.StudentName,
    s.EnrollmentNo,
    s.Branch,
    s.Semester,
    SUM(ISNULL(m.CIA1,0)+ISNULL(m.CIA2,0)+ISNULL(m.CIA3,0))                           AS TotalMarks,
    COUNT(DISTINCT m.Subject)                                                            AS Subjects,
    CAST(AVG(CAST(ISNULL(m.CIA1,0)+ISNULL(m.CIA2,0)+ISNULL(m.CIA3,0) AS FLOAT))
         AS DECIMAL(5,1))                                                                AS AvgMarks,
    CASE
        WHEN AVG(CAST(ISNULL(m.CIA1,0)+ISNULL(m.CIA2,0)+ISNULL(m.CIA3,0) AS FLOAT)) >= 135 THEN 'O'
        WHEN AVG(CAST(ISNULL(m.CIA1,0)+ISNULL(m.CIA2,0)+ISNULL(m.CIA3,0) AS FLOAT)) >= 120 THEN 'A+'
        WHEN AVG(CAST(ISNULL(m.CIA1,0)+ISNULL(m.CIA2,0)+ISNULL(m.CIA3,0) AS FLOAT)) >= 105 THEN 'A'
        WHEN AVG(CAST(ISNULL(m.CIA1,0)+ISNULL(m.CIA2,0)+ISNULL(m.CIA3,0) AS FLOAT)) >= 90  THEN 'B+'
        WHEN AVG(CAST(ISNULL(m.CIA1,0)+ISNULL(m.CIA2,0)+ISNULL(m.CIA3,0) AS FLOAT)) >= 75  THEN 'B'
        WHEN AVG(CAST(ISNULL(m.CIA1,0)+ISNULL(m.CIA2,0)+ISNULL(m.CIA3,0) AS FLOAT)) >= 60  THEN 'C'
        WHEN AVG(CAST(ISNULL(m.CIA1,0)+ISNULL(m.CIA2,0)+ISNULL(m.CIA3,0) AS FLOAT)) >= 50  THEN 'P'
        ELSE 'F'
    END AS Grade
FROM Students s
LEFT JOIN CIAMarks m ON s.StudentID = m.StudentID
GROUP BY s.StudentID, s.StudentName, s.EnrollmentNo, s.Branch, s.Semester;
GO

-- ================================================================
-- SAMPLE DATA: Users
-- ================================================================
INSERT INTO Users (Username, Password, Email) VALUES
('admin',   'admin123',   'admin@college.edu'),
('teacher', 'teacher123', 'teacher@college.edu');
GO

-- ================================================================
-- SAMPLE DATA: Students
-- ================================================================
INSERT INTO Students (StudentName, EnrollmentNo, Branch, Semester, Gender, ContactNo, Email) VALUES
('Aarav Shah',       '220010101001', 'Computer Science',       '5', 'Male',   '9876543210', 'aarav@student.edu'),
('Priya Mehta',      '220010101002', 'Computer Science',       '5', 'Female', '9876543211', 'priya@student.edu'),
('Rohan Patel',      '220010101003', 'Information Technology', '5', 'Male',   '9876543212', 'rohan@student.edu'),
('Sneha Joshi',      '220010101004', 'Information Technology', '5', 'Female', '9876543213', 'sneha@student.edu'),
('Karan Desai',      '220010101005', 'Electronics',            '3', 'Male',   '9876543214', 'karan@student.edu'),
('Ananya Verma',     '220010101006', 'Computer Science',       '3', 'Female', '9876543215', 'ananya@student.edu'),
('Vikram Rao',       '220010101007', 'Mechanical',             '3', 'Male',   '9876543216', 'vikram@student.edu'),
('Pooja Nair',       '220010101008', 'Computer Science',       '5', 'Female', '9876543217', 'pooja@student.edu'),
('Arjun Sharma',     '220010101009', 'Civil',                  '5', 'Male',   '9876543218', 'arjun@student.edu'),
('Divya Gupta',      '220010101010', 'Information Technology', '7', 'Female', '9876543219', 'divya@student.edu');
GO

-- ================================================================
-- SAMPLE DATA: CIA Marks
-- ================================================================
INSERT INTO CIAMarks (StudentID, Subject, CIA1, CIA2, CIA3, Remarks) VALUES
(1,  'DBMS',             45, 43, 47, 'Excellent performance'),
(1,  'Operating System', 42, 44, 46, 'Good understanding'),
(2,  'DBMS',             48, 47, 49, 'Outstanding student'),
(2,  'Operating System', 46, 48, 47, 'Consistent performer'),
(3,  'DBMS',             35, 38, 37, 'Needs improvement'),
(3,  'Operating System', 32, 35, 34, 'Average performance'),
(4,  'DBMS',             40, 42, 41, 'Good progress'),
(4,  'Operating System', 38, 40, 39, 'Satisfactory'),
(5,  'Circuit Theory',   28, 30, 27, 'Struggling - needs help'),
(5,  'Electronics',      30, 32, 29, 'Below average'),
(6,  'DBMS',             50, 49, 48, 'Top of class'),
(6,  'Operating System', 47, 50, 49, 'Exceptional'),
(7,  'Engg Maths',       22, 25, 23, 'Requires attention'),
(8,  'DBMS',             44, 45, 43, 'Very good'),
(9,  'Structures',       38, 40, 37, 'Good understanding'),
(10, 'DBMS',             36, 38, 37, 'Average'),
(10, 'Software Engg',    40, 42, 41, 'Good effort');
GO

-- ================================================================
-- VERIFY
-- ================================================================
SELECT 'Users'    AS TableName, COUNT(*) AS Records FROM Users    UNION ALL
SELECT 'Students' AS TableName, COUNT(*) AS Records FROM Students UNION ALL
SELECT 'CIAMarks' AS TableName, COUNT(*) AS Records FROM CIAMarks;
GO

PRINT '============================================';
PRINT ' StudentManagementDB created successfully!';
PRINT ' Login: admin / admin123';
PRINT ' Login: teacher / teacher123';
PRINT '============================================';
GO

-- ================================================================
-- TO CREATE .BAK FILE - run this after the above:
-- (Change path if needed)
-- ================================================================
-- BACKUP DATABASE StudentManagementDB
-- TO DISK = 'C:\Backup\StudentManagementDB.bak'
-- WITH FORMAT, NAME = 'StudentManagementDB Full Backup';
-- GO
