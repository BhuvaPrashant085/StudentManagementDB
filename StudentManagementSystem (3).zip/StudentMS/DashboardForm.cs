using System.Data;
using System.Configuration;
using System.Data.SqlClient;
using System;
using System.Drawing;
using System.Windows.Forms;

namespace StudentMS
{
    public partial class DashboardForm : Form
    {
        private string _userFullName;
        private string _userRole;

        public DashboardForm(string fullName, string role)
        {
            _userFullName = fullName;
            _userRole = role;
            InitializeComponent();
        }

        private void DashboardForm_Load(object sender, EventArgs e)
        {
            lblUserName.Text = "👤 " + _userFullName;
            lblRole.Text = _userRole;
            LoadStats();
        }

        private void LoadStats()
        {
            object totalStudents = DBHelper.ExecuteScalar("SELECT COUNT(*) FROM Students");
            object totalMarks    = DBHelper.ExecuteScalar("SELECT COUNT(*) FROM CIAMarks WHERE CIA1 IS NOT NULL");
            object avgMarks      = DBHelper.ExecuteScalar("SELECT ISNULL(AVG(CAST(CIA1+CIA2+CIA3 AS FLOAT)/3),0) FROM CIAMarks WHERE CIA1 IS NOT NULL");
            object topStudent    = DBHelper.ExecuteScalar("SELECT TOP 1 StudentName FROM CIAMarks WHERE CIA1 IS NOT NULL ORDER BY (CIA1+CIA2+CIA3) DESC");

            lblTotalStudents.Text = totalStudents != null ? totalStudents.ToString() : "0";
            lblTotalMarks.Text    = totalMarks != null ? totalMarks.ToString() : "0";
            lblAvgMarks.Text      = avgMarks != null ? Math.Round(Convert.ToDouble(avgMarks), 1).ToString() : "0";
            lblTopStudent.Text    = topStudent != null ? topStudent.ToString() : "—";
        }

        private void btnStudents_Click(object sender, EventArgs e)
        {
            new StudentForm().ShowDialog();
            LoadStats();
        }

        private void btnMarks_Click(object sender, EventArgs e)
        {
            new MarksForm().ShowDialog();
            LoadStats();
        }

        private void btnLeaderboard_Click(object sender, EventArgs e)
        {
            new LeaderboardForm().ShowDialog();
        }

        private void btnLogout_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Are you sure you want to logout?", "Logout",
                MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                new LoginForm().Show();
                this.Close();
            }
        }

        private void DashboardForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            Application.Exit();
        }
    }
}
