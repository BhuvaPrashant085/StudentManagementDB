using System.Configuration;
using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace StudentMS
{
    public partial class StudentForm : Form
    {
        public StudentForm() { InitializeComponent(); }

        private void StudentForm_Load(object sender, EventArgs e) => LoadStudents();

        private void LoadStudents(string search = "")
        {
            string query = @"SELECT StudentID, EnrollmentNo, StudentName, Email, Phone, 
                                    Branch, Semester, Gender, CreatedDate
                             FROM Students";
            if (!string.IsNullOrEmpty(search))
                query += " WHERE StudentName LIKE @s OR EnrollmentNo LIKE @s OR Branch LIKE @s";
            query += " ORDER BY StudentName";

            SqlParameter[] p = string.IsNullOrEmpty(search) ? null :
                new[] { new SqlParameter("@s", "%" + search + "%") };

            DataTable dt = DBHelper.ExecuteQuery(query, p);
            dgvStudents.DataSource = dt;
            lblCount.Text = $"Total: {dt.Rows.Count} students";
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            ClearForm();
            ToggleForm(true);
            btnSave.Tag = "ADD";
        }

        private void btnEdit_Click(object sender, EventArgs e)
        {
            if (dgvStudents.SelectedRows.Count == 0)
            { MessageBox.Show("Please select a student to edit.", "Info", MessageBoxButtons.OK, MessageBoxIcon.Information); return; }

            DataGridViewRow row = dgvStudents.SelectedRows[0];
            txtEnrollment.Text = row.Cells["EnrollmentNo"].Value.ToString();
            txtStudentName.Text = row.Cells["StudentName"].Value.ToString();
            txtEmail.Text = row.Cells["Email"].Value?.ToString() ?? "";
            txtPhone.Text = row.Cells["Phone"].Value?.ToString() ?? "";
            txtBranch.Text = row.Cells["Branch"].Value?.ToString() ?? "";
            cmbSemester.SelectedItem = row.Cells["Semester"].Value?.ToString();
            cmbGender.SelectedItem = row.Cells["Gender"].Value?.ToString();
            btnSave.Tag = row.Cells["StudentID"].Value.ToString();
            ToggleForm(true);
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            if (dgvStudents.SelectedRows.Count == 0)
            { MessageBox.Show("Please select a student to delete.", "Info", MessageBoxButtons.OK, MessageBoxIcon.Information); return; }

            if (MessageBox.Show("Delete this student? This will also remove their marks.",
                "Confirm Delete", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) == DialogResult.Yes)
            {
                int id = Convert.ToInt32(dgvStudents.SelectedRows[0].Cells["StudentID"].Value);
                DBHelper.ExecuteNonQuery("DELETE FROM CIAMarks WHERE StudentID=@id", new[] { new SqlParameter("@id", id) });
                DBHelper.ExecuteNonQuery("DELETE FROM Students WHERE StudentID=@id", new[] { new SqlParameter("@id", id) });
                LoadStudents();
            }
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txtEnrollment.Text) || string.IsNullOrEmpty(txtStudentName.Text))
            { MessageBox.Show("Enrollment No and Student Name are required.", "Validation", MessageBoxButtons.OK, MessageBoxIcon.Warning); return; }

            string tag = btnSave.Tag?.ToString();
            if (tag == "ADD")
            {
                string q = @"INSERT INTO Students (EnrollmentNo,StudentName,Email,Phone,Branch,Semester,Gender,CreatedDate)
                             VALUES (@en,@sn,@em,@ph,@br,@sem,@gen,GETDATE())";
                DBHelper.ExecuteNonQuery(q, GetParams());
                MessageBox.Show("✅ Student added successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                string q = @"UPDATE Students SET EnrollmentNo=@en,StudentName=@sn,Email=@em,
                             Phone=@ph,Branch=@br,Semester=@sem,Gender=@gen WHERE StudentID=@id";
                var pList = new System.Collections.Generic.List<SqlParameter>(GetParams());
                pList.Add(new SqlParameter("@id", int.Parse(tag)));
                DBHelper.ExecuteNonQuery(q, pList.ToArray());
                MessageBox.Show("✅ Student updated successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            ToggleForm(false);
            LoadStudents();
        }

        private SqlParameter[] GetParams() => new[]
        {
            new SqlParameter("@en",  txtEnrollment.Text.Trim()),
            new SqlParameter("@sn",  txtStudentName.Text.Trim()),
            new SqlParameter("@em",  txtEmail.Text.Trim()),
            new SqlParameter("@ph",  txtPhone.Text.Trim()),
            new SqlParameter("@br",  txtBranch.Text.Trim()),
            new SqlParameter("@sem", cmbSemester.SelectedItem?.ToString() ?? ""),
            new SqlParameter("@gen", cmbGender.SelectedItem?.ToString() ?? "")
        };

        private void btnCancel_Click(object sender, EventArgs e) => ToggleForm(false);

        private void txtSearch_TextChanged(object sender, EventArgs e) => LoadStudents(txtSearch.Text.Trim());

        private void ToggleForm(bool show)
        {
            panelForm.Visible = show;
            panelGrid.Visible = !show;
        }

        private void ClearForm()
        {
            txtEnrollment.Clear(); txtStudentName.Clear(); txtEmail.Clear();
            txtPhone.Clear(); txtBranch.Clear();
            cmbSemester.SelectedIndex = 0; cmbGender.SelectedIndex = 0;
        }
    }
}
