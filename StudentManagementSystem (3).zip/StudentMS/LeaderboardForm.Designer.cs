namespace StudentMS
{
    partial class LeaderboardForm
    {
        private System.ComponentModel.IContainer components = null;
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null)) components.Dispose();
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.panelHeader     = new System.Windows.Forms.Panel();
            this.lblTitle        = new System.Windows.Forms.Label();
            this.panelToolbar    = new System.Windows.Forms.Panel();
            this.txtSearch       = new System.Windows.Forms.TextBox();
            this.cmbFilter       = new System.Windows.Forms.ComboBox();
            this.dgvLeaderboard  = new System.Windows.Forms.DataGridView();
            this.panelHeader.SuspendLayout();
            this.panelToolbar.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvLeaderboard)).BeginInit();
            this.SuspendLayout();

            this.panelHeader.BackColor = System.Drawing.Color.FromArgb(109, 40, 217);
            this.panelHeader.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelHeader.Height = 55;
            this.panelHeader.Controls.Add(this.lblTitle);

            this.lblTitle.AutoSize = false;
            this.lblTitle.Font = new System.Drawing.Font("Segoe UI", 15F, System.Drawing.FontStyle.Bold);
            this.lblTitle.ForeColor = System.Drawing.Color.White;
            this.lblTitle.Text = "🏆  Student Leaderboard";
            this.lblTitle.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblTitle.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lblTitle.Padding = new System.Windows.Forms.Padding(15, 0, 0, 0);

            this.panelToolbar.BackColor = System.Drawing.Color.White;
            this.panelToolbar.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelToolbar.Height = 55;
            this.panelToolbar.Padding = new System.Windows.Forms.Padding(15, 10, 15, 10);
            this.panelToolbar.Controls.Add(this.txtSearch);
            this.panelToolbar.Controls.Add(this.cmbFilter);

            this.txtSearch.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.txtSearch.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtSearch.Size = new System.Drawing.Size(260, 32);
            this.txtSearch.Location = new System.Drawing.Point(15, 12);
            this.txtSearch.TextChanged += new System.EventHandler(this.txtSearch_TextChanged);

            this.cmbFilter.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.cmbFilter.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbFilter.Items.AddRange(new object[] { "All", "Computer Science", "Information Technology", "Electronics", "Mechanical" });
            this.cmbFilter.SelectedIndex = 0;
            this.cmbFilter.Size = new System.Drawing.Size(200, 32);
            this.cmbFilter.Location = new System.Drawing.Point(290, 12);
            this.cmbFilter.SelectedIndexChanged += new System.EventHandler(this.cmbFilter_SelectedIndexChanged);

            this.dgvLeaderboard.AllowUserToAddRows = false;
            this.dgvLeaderboard.ReadOnly = true;
            this.dgvLeaderboard.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvLeaderboard.BackgroundColor = System.Drawing.Color.White;
            this.dgvLeaderboard.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dgvLeaderboard.RowHeadersVisible = false;
            this.dgvLeaderboard.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvLeaderboard.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.dgvLeaderboard.ColumnHeadersDefaultCellStyle.BackColor = System.Drawing.Color.FromArgb(109, 40, 217);
            this.dgvLeaderboard.ColumnHeadersDefaultCellStyle.ForeColor = System.Drawing.Color.White;
            this.dgvLeaderboard.ColumnHeadersDefaultCellStyle.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.dgvLeaderboard.ColumnHeadersHeight = 38;
            this.dgvLeaderboard.RowTemplate.Height = 30;
            this.dgvLeaderboard.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvLeaderboard.DataBindingComplete += new System.Windows.Forms.DataGridViewBindingCompleteEventHandler(this.dgvLeaderboard_DataBindingComplete);

            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1000, 620);
            this.Controls.Add(this.dgvLeaderboard);
            this.Controls.Add(this.panelToolbar);
            this.Controls.Add(this.panelHeader);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Student Leaderboard";
            this.Load += new System.EventHandler(this.LeaderboardForm_Load);

            this.panelHeader.ResumeLayout(false);
            this.panelToolbar.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvLeaderboard)).EndInit();
            this.ResumeLayout(false);
        }

        private System.Windows.Forms.Panel panelHeader, panelToolbar;
        private System.Windows.Forms.Label lblTitle;
        private System.Windows.Forms.DataGridView dgvLeaderboard;
        private System.Windows.Forms.TextBox txtSearch;
        private System.Windows.Forms.ComboBox cmbFilter;
    }
}
