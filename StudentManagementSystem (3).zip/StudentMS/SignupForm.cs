using System.Data;
using System.Configuration;
using System;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace StudentMS
{
    public partial class SignupForm : Form
    {
        public SignupForm()
        {
            InitializeComponent();
        }

        private void btnRegister_Click(object sender, EventArgs e)
        {
            string fullName = txtFullName.Text.Trim();
            string username = txtUsername.Text.Trim();
            string password = txtPassword.Text.Trim();
            string confirm  = txtConfirm.Text.Trim();
            string email    = txtEmail.Text.Trim();
            string role     = cmbRole.SelectedItem?.ToString() ?? "Student";

            if (string.IsNullOrEmpty(fullName) || string.IsNullOrEmpty(username) ||
                string.IsNullOrEmpty(password) || string.IsNullOrEmpty(email))
            {
                MessageBox.Show("All fields are required.", "Validation", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            if (password != confirm)
            {
                MessageBox.Show("Passwords do not match.", "Validation", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            if (password.Length < 6)
            {
                MessageBox.Show("Password must be at least 6 characters.", "Validation", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            // Check if username exists
            object exists = DBHelper.ExecuteScalar("SELECT COUNT(*) FROM Users WHERE Username=@u",
                new SqlParameter[] { new SqlParameter("@u", username) });
            if (Convert.ToInt32(exists) > 0)
            {
                MessageBox.Show("Username already exists. Choose another.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            string query = @"INSERT INTO Users (FullName, Username, Password, Email, Role, IsActive, CreatedDate)
                             VALUES (@fn, @u, @p, @e, @r, 1, GETDATE())";
            SqlParameter[] parms = {
                new SqlParameter("@fn", fullName),
                new SqlParameter("@u",  username),
                new SqlParameter("@p",  password),
                new SqlParameter("@e",  email),
                new SqlParameter("@r",  role)
            };

            int result = DBHelper.ExecuteNonQuery(query, parms);
            if (result > 0)
            {
                MessageBox.Show("✅ Registration successful! You can now login.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                this.Close();
            }
        }

        private void btnCancel_Click(object sender, EventArgs e) => this.Close();
    }
}
