using System;
using System.Data;
using System.Windows.Forms;
using System.Drawing;

namespace StudentMS
{
    public partial class LeaderboardForm : Form
    {
        public LeaderboardForm() { InitializeComponent(); }

        private void LeaderboardForm_Load(object sender, EventArgs e) => LoadLeaderboard();

        private void LoadLeaderboard(string filter = "")
        {
            string query = @"SELECT ROW_NUMBER() OVER (ORDER BY (CIA1+CIA2+CIA3) DESC) AS Rank,
                                    s.EnrollmentNo, s.StudentName, s.Branch, s.Semester,
                                    m.CIA1, m.CIA2, m.CIA3,
                                    (m.CIA1+m.CIA2+m.CIA3) AS Total,
                                    CAST((m.CIA1+m.CIA2+m.CIA3)/100.0*100 AS DECIMAL(5,1)) AS Percentage
                             FROM CIAMarks m
                             JOIN Students s ON m.StudentID = s.StudentID
                             WHERE m.CIA1 IS NOT NULL AND m.CIA2 IS NOT NULL AND m.CIA3 IS NOT NULL";
            if (!string.IsNullOrEmpty(filter))
                query += " AND (s.StudentName LIKE @f OR s.Branch LIKE @f)";
            query += " ORDER BY Total DESC";

            SqlParameter[] p = string.IsNullOrEmpty(filter) ? null :
                new System.Data.SqlClient.SqlParameter[] { new System.Data.SqlClient.SqlParameter("@f", "%" + filter + "%") };

            DataTable dt = DBHelper.ExecuteQuery(query, p);
            dgvLeaderboard.DataSource = dt;

            // Color top 3 rows
            dgvLeaderboard.ClearSelection();
        }

        private void dgvLeaderboard_DataBindingComplete(object sender, DataGridViewBindingCompleteEventArgs e)
        {
            foreach (DataGridViewRow row in dgvLeaderboard.Rows)
            {
                int rank = Convert.ToInt32(row.Cells["Rank"].Value);
                if (rank == 1)      { row.DefaultCellStyle.BackColor = Color.FromArgb(255, 215, 0); row.DefaultCellStyle.Font = new Font("Segoe UI", 9F, FontStyle.Bold); }
                else if (rank == 2) { row.DefaultCellStyle.BackColor = Color.FromArgb(220, 220, 220); }
                else if (rank == 3) { row.DefaultCellStyle.BackColor = Color.FromArgb(205, 127, 50, 80); }
            }
        }

        private void txtSearch_TextChanged(object sender, EventArgs e) => LoadLeaderboard(txtSearch.Text.Trim());

        private void cmbFilter_SelectedIndexChanged(object sender, EventArgs e)
        {
            string selected = cmbFilter.SelectedItem?.ToString();
            if (selected == "All") LoadLeaderboard();
            else LoadLeaderboard(selected);
        }
    }
}
