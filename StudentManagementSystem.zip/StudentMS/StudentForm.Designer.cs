namespace StudentMS
{
    partial class StudentForm
    {
        private System.ComponentModel.IContainer components = null;
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null)) components.Dispose();
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.panelHeader  = new System.Windows.Forms.Panel();
            this.lblTitle     = new System.Windows.Forms.Label();
            this.panelGrid    = new System.Windows.Forms.Panel();
            this.panelForm    = new System.Windows.Forms.Panel();
            this.dgvStudents  = new System.Windows.Forms.DataGridView();
            this.txtSearch    = new System.Windows.Forms.TextBox();
            this.lblCount     = new System.Windows.Forms.Label();
            this.btnAdd       = new System.Windows.Forms.Button();
            this.btnEdit      = new System.Windows.Forms.Button();
            this.btnDelete    = new System.Windows.Forms.Button();
            // Form fields
            this.lblFormTitle   = new System.Windows.Forms.Label();
            this.txtEnrollment  = new System.Windows.Forms.TextBox();
            this.txtStudentName = new System.Windows.Forms.TextBox();
            this.txtEmail       = new System.Windows.Forms.TextBox();
            this.txtPhone       = new System.Windows.Forms.TextBox();
            this.txtBranch      = new System.Windows.Forms.TextBox();
            this.cmbSemester    = new System.Windows.Forms.ComboBox();
            this.cmbGender      = new System.Windows.Forms.ComboBox();
            this.btnSave        = new System.Windows.Forms.Button();
            this.btnCancel      = new System.Windows.Forms.Button();
            this.panelHeader.SuspendLayout();
            this.panelGrid.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvStudents)).BeginInit();
            this.SuspendLayout();

            // Header
            this.panelHeader.BackColor = System.Drawing.Color.FromArgb(30, 58, 138);
            this.panelHeader.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelHeader.Height = 55;
            this.panelHeader.Controls.Add(this.lblTitle);

            this.lblTitle.AutoSize = false;
            this.lblTitle.Font = new System.Drawing.Font("Segoe UI", 15F, System.Drawing.FontStyle.Bold);
            this.lblTitle.ForeColor = System.Drawing.Color.White;
            this.lblTitle.Text = "👥  Student Management";
            this.lblTitle.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblTitle.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lblTitle.Padding = new System.Windows.Forms.Padding(15, 0, 0, 0);

            // panelGrid
            this.panelGrid.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelGrid.BackColor = System.Drawing.Color.FromArgb(240, 244, 255);
            this.panelGrid.Padding = new System.Windows.Forms.Padding(15);
            this.panelGrid.Controls.Add(this.dgvStudents);
            this.panelGrid.Controls.Add(this.txtSearch);
            this.panelGrid.Controls.Add(this.lblCount);
            this.panelGrid.Controls.Add(this.btnAdd);
            this.panelGrid.Controls.Add(this.btnEdit);
            this.panelGrid.Controls.Add(this.btnDelete);

            // Toolbar
            this.txtSearch.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.txtSearch.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtSearch.Size = new System.Drawing.Size(250, 32);
            this.txtSearch.Location = new System.Drawing.Point(15, 15);
            this.txtSearch.PlaceholderText = "🔍 Search students...";
            this.txtSearch.TextChanged += new System.EventHandler(this.txtSearch_TextChanged);

            MakeBtn(this.btnAdd,    "➕ Add",    System.Drawing.Color.FromArgb(5,150,105),  650, 15, this.btnAdd_Click);
            MakeBtn(this.btnEdit,   "✏️ Edit",   System.Drawing.Color.FromArgb(30,58,138),  750, 15, this.btnEdit_Click);
            MakeBtn(this.btnDelete, "🗑 Delete", System.Drawing.Color.FromArgb(239,68,68),  850, 15, this.btnDelete_Click);

            this.lblCount.AutoSize = true;
            this.lblCount.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.lblCount.ForeColor = System.Drawing.Color.Gray;
            this.lblCount.Location = new System.Drawing.Point(15, 55);

            // DataGridView
            this.dgvStudents.AllowUserToAddRows = false;
            this.dgvStudents.AllowUserToDeleteRows = false;
            this.dgvStudents.ReadOnly = true;
            this.dgvStudents.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvStudents.BackgroundColor = System.Drawing.Color.White;
            this.dgvStudents.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dgvStudents.RowHeadersVisible = false;
            this.dgvStudents.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvStudents.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.dgvStudents.ColumnHeadersDefaultCellStyle.BackColor = System.Drawing.Color.FromArgb(30, 58, 138);
            this.dgvStudents.ColumnHeadersDefaultCellStyle.ForeColor = System.Drawing.Color.White;
            this.dgvStudents.ColumnHeadersDefaultCellStyle.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.dgvStudents.ColumnHeadersHeight = 35;
            this.dgvStudents.RowTemplate.Height = 28;
            this.dgvStudents.AlternatingRowsDefaultCellStyle.BackColor = System.Drawing.Color.FromArgb(240, 244, 255);
            this.dgvStudents.Size = new System.Drawing.Size(960, 460);
            this.dgvStudents.Location = new System.Drawing.Point(15, 78);

            // panelForm (Add/Edit form)
            this.panelForm.BackColor = System.Drawing.Color.White;
            this.panelForm.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelForm.Visible = false;
            this.panelForm.Padding = new System.Windows.Forms.Padding(40);
            this.panelForm.Controls.Add(this.lblFormTitle);
            this.panelForm.Controls.Add(this.btnSave);
            this.panelForm.Controls.Add(this.btnCancel);

            this.lblFormTitle.AutoSize = false;
            this.lblFormTitle.Font = new System.Drawing.Font("Segoe UI", 14F, System.Drawing.FontStyle.Bold);
            this.lblFormTitle.ForeColor = System.Drawing.Color.FromArgb(30, 58, 138);
            this.lblFormTitle.Text = "Student Details";
            this.lblFormTitle.Size = new System.Drawing.Size(400, 40);
            this.lblFormTitle.Location = new System.Drawing.Point(40, 20);

            AddFormField("Enrollment No *", this.txtEnrollment, 70, 40);
            AddFormField("Student Name *",  this.txtStudentName, 70, 300);
            AddFormField("Email",           this.txtEmail,       150, 40);
            AddFormField("Phone",           this.txtPhone,       150, 300);
            AddFormField("Branch/Course",   this.txtBranch,      230, 40);

            var semLbl = MakeFormLabel("Semester", 230, 300);
            this.cmbSemester.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbSemester.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.cmbSemester.Items.AddRange(new object[] {"1","2","3","4","5","6","7","8"});
            this.cmbSemester.SelectedIndex = 0;
            this.cmbSemester.Size = new System.Drawing.Size(220, 30);
            this.cmbSemester.Location = new System.Drawing.Point(300, 254);

            var genLbl = MakeFormLabel("Gender", 310, 40);
            this.cmbGender.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbGender.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.cmbGender.Items.AddRange(new object[] {"Male","Female","Other"});
            this.cmbGender.SelectedIndex = 0;
            this.cmbGender.Size = new System.Drawing.Size(220, 30);
            this.cmbGender.Location = new System.Drawing.Point(40, 334);

            this.panelForm.Controls.Add(semLbl);
            this.panelForm.Controls.Add(this.cmbSemester);
            this.panelForm.Controls.Add(genLbl);
            this.panelForm.Controls.Add(this.cmbGender);

            MakeBtn(this.btnSave,   "💾 Save",   System.Drawing.Color.FromArgb(5,150,105),  40,  390, this.btnSave_Click);
            MakeBtn(this.btnCancel, "✖ Cancel", System.Drawing.Color.FromArgb(239,68,68), 160, 390, this.btnCancel_Click);

            // Form
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1000, 620);
            this.Controls.Add(this.panelForm);
            this.Controls.Add(this.panelGrid);
            this.Controls.Add(this.panelHeader);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Manage Students";
            this.Load += new System.EventHandler(this.StudentForm_Load);

            this.panelHeader.ResumeLayout(false);
            this.panelGrid.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvStudents)).EndInit();
            this.ResumeLayout(false);
        }

        private void MakeBtn(System.Windows.Forms.Button btn, string text,
            System.Drawing.Color color, int x, int y, System.EventHandler handler)
        {
            btn.BackColor = color;
            btn.FlatAppearance.BorderSize = 0;
            btn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            btn.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            btn.ForeColor = System.Drawing.Color.White;
            btn.Text = text;
            btn.Size = new System.Drawing.Size(100, 34);
            btn.Location = new System.Drawing.Point(x, y);
            btn.Cursor = System.Windows.Forms.Cursors.Hand;
            btn.Click += handler;
        }

        private void AddFormField(string label, System.Windows.Forms.TextBox txt, int y, int x)
        {
            var lbl = MakeFormLabel(label, y, x);
            txt.Font = new System.Drawing.Font("Segoe UI", 10F);
            txt.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            txt.Size = new System.Drawing.Size(220, 30);
            txt.Location = new System.Drawing.Point(x, y + 22);
            txt.BackColor = System.Drawing.Color.FromArgb(245, 247, 255);
            this.panelForm.Controls.Add(lbl);
            this.panelForm.Controls.Add(txt);
        }

        private System.Windows.Forms.Label MakeFormLabel(string text, int y, int x)
        {
            var lbl = new System.Windows.Forms.Label();
            lbl.AutoSize = false;
            lbl.Font = new System.Drawing.Font("Segoe UI", 8F, System.Drawing.FontStyle.Bold);
            lbl.ForeColor = System.Drawing.Color.FromArgb(80, 80, 110);
            lbl.Text = text.ToUpper();
            lbl.Size = new System.Drawing.Size(220, 20);
            lbl.Location = new System.Drawing.Point(x, y);
            return lbl;
        }

        private System.Windows.Forms.Panel panelHeader, panelGrid, panelForm;
        private System.Windows.Forms.Label lblTitle, lblCount, lblFormTitle;
        private System.Windows.Forms.DataGridView dgvStudents;
        private System.Windows.Forms.TextBox txtSearch, txtEnrollment, txtStudentName, txtEmail, txtPhone, txtBranch;
        private System.Windows.Forms.ComboBox cmbSemester, cmbGender;
        private System.Windows.Forms.Button btnAdd, btnEdit, btnDelete, btnSave, btnCancel;
    }
}
