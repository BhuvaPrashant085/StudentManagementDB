using System;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Windows.Forms;

namespace StudentMS
{
    public partial class LoginForm : Form
    {
        public LoginForm()
        {
            InitializeComponent();
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            string username = txtUsername.Text.Trim();
            string password = txtPassword.Text.Trim();

            if (string.IsNullOrEmpty(username) || string.IsNullOrEmpty(password))
            {
                MessageBox.Show("Please enter username and password.", "Validation", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            string query = "SELECT COUNT(*) FROM Users WHERE Username=@u AND Password=@p AND IsActive=1";
            SqlParameter[] parms = {
                new SqlParameter("@u", username),
                new SqlParameter("@p", password)
            };

            object result = DBHelper.ExecuteScalar(query, parms);
            int count = result != null ? Convert.ToInt32(result) : 0;

            if (count > 0)
            {
                // Get user role
                string roleQuery = "SELECT Role, FullName FROM Users WHERE Username=@u AND Password=@p";
                DataTable dt = DBHelper.ExecuteQuery(roleQuery, new SqlParameter[] {
                    new SqlParameter("@u", username),
                    new SqlParameter("@p", password)
                });

                string role = dt.Rows[0]["Role"].ToString();
                string fullName = dt.Rows[0]["FullName"].ToString();

                DashboardForm dash = new DashboardForm(fullName, role);
                dash.Show();
                this.Hide();
            }
            else
            {
                lblError.Text = "❌ Invalid username or password!";
                lblError.Visible = true;
                txtPassword.Clear();
                txtPassword.Focus();
            }
        }

        private void btnSignup_Click(object sender, EventArgs e)
        {
            SignupForm signup = new SignupForm();
            signup.ShowDialog();
        }

        private void txtPassword_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
                btnLogin_Click(sender, e);
        }

        private void lblError_Click(object sender, EventArgs e) { }

        private void chkShowPassword_CheckedChanged(object sender, EventArgs e)
        {
            txtPassword.UseSystemPasswordChar = !chkShowPassword.Checked;
        }
    }
}
