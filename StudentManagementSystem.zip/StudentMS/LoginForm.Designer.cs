namespace StudentMS
{
    partial class LoginForm
    {
        private System.ComponentModel.IContainer components = null;
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null)) components.Dispose();
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.panelMain = new System.Windows.Forms.Panel();
            this.panelLeft = new System.Windows.Forms.Panel();
            this.lblAppTitle = new System.Windows.Forms.Label();
            this.lblAppSubtitle = new System.Windows.Forms.Label();
            this.lblIcon = new System.Windows.Forms.Label();
            this.panelRight = new System.Windows.Forms.Panel();
            this.lblWelcome = new System.Windows.Forms.Label();
            this.lblLoginSub = new System.Windows.Forms.Label();
            this.lblUsername = new System.Windows.Forms.Label();
            this.txtUsername = new System.Windows.Forms.TextBox();
            this.lblPasswordLbl = new System.Windows.Forms.Label();
            this.txtPassword = new System.Windows.Forms.TextBox();
            this.chkShowPassword = new System.Windows.Forms.CheckBox();
            this.btnLogin = new System.Windows.Forms.Button();
            this.lblError = new System.Windows.Forms.Label();
            this.lblNoAccount = new System.Windows.Forms.Label();
            this.btnSignup = new System.Windows.Forms.Button();
            this.panelMain.SuspendLayout();
            this.panelLeft.SuspendLayout();
            this.panelRight.SuspendLayout();
            this.SuspendLayout();

            // panelMain
            this.panelMain.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelMain.Controls.Add(this.panelRight);
            this.panelMain.Controls.Add(this.panelLeft);
            this.panelMain.Location = new System.Drawing.Point(0, 0);
            this.panelMain.Size = new System.Drawing.Size(900, 550);

            // panelLeft - blue branding side
            this.panelLeft.BackColor = System.Drawing.Color.FromArgb(30, 58, 138);
            this.panelLeft.Controls.Add(this.lblIcon);
            this.panelLeft.Controls.Add(this.lblAppTitle);
            this.panelLeft.Controls.Add(this.lblAppSubtitle);
            this.panelLeft.Dock = System.Windows.Forms.DockStyle.Left;
            this.panelLeft.Size = new System.Drawing.Size(380, 550);

            // lblIcon
            this.lblIcon.AutoSize = false;
            this.lblIcon.Font = new System.Drawing.Font("Segoe UI Emoji", 52F);
            this.lblIcon.ForeColor = System.Drawing.Color.White;
            this.lblIcon.Text = "🎓";
            this.lblIcon.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblIcon.Size = new System.Drawing.Size(380, 120);
            this.lblIcon.Location = new System.Drawing.Point(0, 140);

            // lblAppTitle
            this.lblAppTitle.AutoSize = false;
            this.lblAppTitle.Font = new System.Drawing.Font("Segoe UI", 22F, System.Drawing.FontStyle.Bold);
            this.lblAppTitle.ForeColor = System.Drawing.Color.White;
            this.lblAppTitle.Text = "Student Management\nSystem";
            this.lblAppTitle.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblAppTitle.Size = new System.Drawing.Size(380, 100);
            this.lblAppTitle.Location = new System.Drawing.Point(0, 270);

            // lblAppSubtitle
            this.lblAppSubtitle.AutoSize = false;
            this.lblAppSubtitle.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.lblAppSubtitle.ForeColor = System.Drawing.Color.FromArgb(180, 210, 255);
            this.lblAppSubtitle.Text = "Track Students · Marks · Leaderboard";
            this.lblAppSubtitle.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblAppSubtitle.Size = new System.Drawing.Size(380, 40);
            this.lblAppSubtitle.Location = new System.Drawing.Point(0, 370);

            // panelRight - login fields
            this.panelRight.BackColor = System.Drawing.Color.White;
            this.panelRight.Controls.Add(this.lblWelcome);
            this.panelRight.Controls.Add(this.lblLoginSub);
            this.panelRight.Controls.Add(this.lblUsername);
            this.panelRight.Controls.Add(this.txtUsername);
            this.panelRight.Controls.Add(this.lblPasswordLbl);
            this.panelRight.Controls.Add(this.txtPassword);
            this.panelRight.Controls.Add(this.chkShowPassword);
            this.panelRight.Controls.Add(this.btnLogin);
            this.panelRight.Controls.Add(this.lblError);
            this.panelRight.Controls.Add(this.lblNoAccount);
            this.panelRight.Controls.Add(this.btnSignup);
            this.panelRight.Dock = System.Windows.Forms.DockStyle.Fill;

            // lblWelcome
            this.lblWelcome.AutoSize = false;
            this.lblWelcome.Font = new System.Drawing.Font("Segoe UI", 20F, System.Drawing.FontStyle.Bold);
            this.lblWelcome.ForeColor = System.Drawing.Color.FromArgb(30, 58, 138);
            this.lblWelcome.Text = "Welcome Back!";
            this.lblWelcome.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lblWelcome.Size = new System.Drawing.Size(380, 50);
            this.lblWelcome.Location = new System.Drawing.Point(60, 100);

            // lblLoginSub
            this.lblLoginSub.AutoSize = false;
            this.lblLoginSub.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.lblLoginSub.ForeColor = System.Drawing.Color.Gray;
            this.lblLoginSub.Text = "Sign in to your account";
            this.lblLoginSub.Size = new System.Drawing.Size(380, 25);
            this.lblLoginSub.Location = new System.Drawing.Point(60, 148);

            // lblUsername
            this.lblUsername.AutoSize = false;
            this.lblUsername.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.lblUsername.ForeColor = System.Drawing.Color.FromArgb(50, 50, 80);
            this.lblUsername.Text = "USERNAME";
            this.lblUsername.Size = new System.Drawing.Size(380, 20);
            this.lblUsername.Location = new System.Drawing.Point(60, 200);

            // txtUsername
            this.txtUsername.Font = new System.Drawing.Font("Segoe UI", 11F);
            this.txtUsername.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtUsername.Size = new System.Drawing.Size(380, 34);
            this.txtUsername.Location = new System.Drawing.Point(60, 222);
            this.txtUsername.BackColor = System.Drawing.Color.FromArgb(245, 247, 255);

            // lblPasswordLbl
            this.lblPasswordLbl.AutoSize = false;
            this.lblPasswordLbl.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.lblPasswordLbl.ForeColor = System.Drawing.Color.FromArgb(50, 50, 80);
            this.lblPasswordLbl.Text = "PASSWORD";
            this.lblPasswordLbl.Size = new System.Drawing.Size(380, 20);
            this.lblPasswordLbl.Location = new System.Drawing.Point(60, 275);

            // txtPassword
            this.txtPassword.Font = new System.Drawing.Font("Segoe UI", 11F);
            this.txtPassword.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtPassword.UseSystemPasswordChar = true;
            this.txtPassword.Size = new System.Drawing.Size(380, 34);
            this.txtPassword.Location = new System.Drawing.Point(60, 297);
            this.txtPassword.BackColor = System.Drawing.Color.FromArgb(245, 247, 255);
            this.txtPassword.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtPassword_KeyDown);

            // chkShowPassword
            this.chkShowPassword.AutoSize = true;
            this.chkShowPassword.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.chkShowPassword.ForeColor = System.Drawing.Color.Gray;
            this.chkShowPassword.Text = "Show Password";
            this.chkShowPassword.Location = new System.Drawing.Point(60, 338);
            this.chkShowPassword.CheckedChanged += new System.EventHandler(this.chkShowPassword_CheckedChanged);

            // btnLogin
            this.btnLogin.BackColor = System.Drawing.Color.FromArgb(30, 58, 138);
            this.btnLogin.FlatAppearance.BorderSize = 0;
            this.btnLogin.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnLogin.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold);
            this.btnLogin.ForeColor = System.Drawing.Color.White;
            this.btnLogin.Text = "LOGIN  →";
            this.btnLogin.Size = new System.Drawing.Size(380, 46);
            this.btnLogin.Location = new System.Drawing.Point(60, 368);
            this.btnLogin.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnLogin.Click += new System.EventHandler(this.btnLogin_Click);

            // lblError
            this.lblError.AutoSize = false;
            this.lblError.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.lblError.ForeColor = System.Drawing.Color.Red;
            this.lblError.Text = "";
            this.lblError.Size = new System.Drawing.Size(380, 22);
            this.lblError.Location = new System.Drawing.Point(60, 420);
            this.lblError.Visible = false;

            // lblNoAccount
            this.lblNoAccount.AutoSize = false;
            this.lblNoAccount.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.lblNoAccount.ForeColor = System.Drawing.Color.Gray;
            this.lblNoAccount.Text = "Don't have an account?";
            this.lblNoAccount.Size = new System.Drawing.Size(200, 25);
            this.lblNoAccount.Location = new System.Drawing.Point(60, 448);

            // btnSignup
            this.btnSignup.BackColor = System.Drawing.Color.Transparent;
            this.btnSignup.FlatAppearance.BorderSize = 0;
            this.btnSignup.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSignup.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline);
            this.btnSignup.ForeColor = System.Drawing.Color.FromArgb(30, 58, 138);
            this.btnSignup.Text = "Register here";
            this.btnSignup.AutoSize = true;
            this.btnSignup.Location = new System.Drawing.Point(248, 448);
            this.btnSignup.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnSignup.Click += new System.EventHandler(this.btnSignup_Click);

            // LoginForm
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(900, 550);
            this.Controls.Add(this.panelMain);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.Name = "LoginForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Student Management System - Login";
            this.BackColor = System.Drawing.Color.White;

            this.panelMain.ResumeLayout(false);
            this.panelLeft.ResumeLayout(false);
            this.panelRight.ResumeLayout(false);
            this.ResumeLayout(false);
        }

        private System.Windows.Forms.Panel panelMain;
        private System.Windows.Forms.Panel panelLeft;
        private System.Windows.Forms.Panel panelRight;
        private System.Windows.Forms.Label lblIcon;
        private System.Windows.Forms.Label lblAppTitle;
        private System.Windows.Forms.Label lblAppSubtitle;
        private System.Windows.Forms.Label lblWelcome;
        private System.Windows.Forms.Label lblLoginSub;
        private System.Windows.Forms.Label lblUsername;
        private System.Windows.Forms.TextBox txtUsername;
        private System.Windows.Forms.Label lblPasswordLbl;
        private System.Windows.Forms.TextBox txtPassword;
        private System.Windows.Forms.CheckBox chkShowPassword;
        private System.Windows.Forms.Button btnLogin;
        private System.Windows.Forms.Label lblError;
        private System.Windows.Forms.Label lblNoAccount;
        private System.Windows.Forms.Button btnSignup;
    }
}
