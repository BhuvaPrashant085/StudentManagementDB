namespace StudentMS
{
    partial class SignupForm
    {
        private System.ComponentModel.IContainer components = null;
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null)) components.Dispose();
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.panelHeader = new System.Windows.Forms.Panel();
            this.lblTitle = new System.Windows.Forms.Label();
            this.lblSubtitle = new System.Windows.Forms.Label();
            this.panelBody = new System.Windows.Forms.Panel();
            this.lblFullName = new System.Windows.Forms.Label();
            this.txtFullName = new System.Windows.Forms.TextBox();
            this.lblUsername = new System.Windows.Forms.Label();
            this.txtUsername = new System.Windows.Forms.TextBox();
            this.lblEmail = new System.Windows.Forms.Label();
            this.txtEmail = new System.Windows.Forms.TextBox();
            this.lblRole = new System.Windows.Forms.Label();
            this.cmbRole = new System.Windows.Forms.ComboBox();
            this.lblPassword = new System.Windows.Forms.Label();
            this.txtPassword = new System.Windows.Forms.TextBox();
            this.lblConfirm = new System.Windows.Forms.Label();
            this.txtConfirm = new System.Windows.Forms.TextBox();
            this.btnRegister = new System.Windows.Forms.Button();
            this.btnCancel = new System.Windows.Forms.Button();
            this.panelHeader.SuspendLayout();
            this.panelBody.SuspendLayout();
            this.SuspendLayout();

            // panelHeader
            this.panelHeader.BackColor = System.Drawing.Color.FromArgb(30, 58, 138);
            this.panelHeader.Controls.Add(this.lblTitle);
            this.panelHeader.Controls.Add(this.lblSubtitle);
            this.panelHeader.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelHeader.Height = 90;

            this.lblTitle.AutoSize = false;
            this.lblTitle.Font = new System.Drawing.Font("Segoe UI", 18F, System.Drawing.FontStyle.Bold);
            this.lblTitle.ForeColor = System.Drawing.Color.White;
            this.lblTitle.Text = "🎓 Create Account";
            this.lblTitle.Size = new System.Drawing.Size(500, 50);
            this.lblTitle.Location = new System.Drawing.Point(30, 10);

            this.lblSubtitle.AutoSize = false;
            this.lblSubtitle.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.lblSubtitle.ForeColor = System.Drawing.Color.FromArgb(180, 210, 255);
            this.lblSubtitle.Text = "Fill in the details below to register";
            this.lblSubtitle.Size = new System.Drawing.Size(400, 25);
            this.lblSubtitle.Location = new System.Drawing.Point(32, 58);

            // panelBody
            this.panelBody.BackColor = System.Drawing.Color.White;
            this.panelBody.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelBody.Controls.Add(this.lblFullName);
            this.panelBody.Controls.Add(this.txtFullName);
            this.panelBody.Controls.Add(this.lblUsername);
            this.panelBody.Controls.Add(this.txtUsername);
            this.panelBody.Controls.Add(this.lblEmail);
            this.panelBody.Controls.Add(this.txtEmail);
            this.panelBody.Controls.Add(this.lblRole);
            this.panelBody.Controls.Add(this.cmbRole);
            this.panelBody.Controls.Add(this.lblPassword);
            this.panelBody.Controls.Add(this.txtPassword);
            this.panelBody.Controls.Add(this.lblConfirm);
            this.panelBody.Controls.Add(this.txtConfirm);
            this.panelBody.Controls.Add(this.btnRegister);
            this.panelBody.Controls.Add(this.btnCancel);

            int lx = 30, rx = 280, w = 220, lh = 18, th = 32, gap = 58;
            int y = 20;

            MakeLabel(this.lblFullName, "FULL NAME", lx, y);
            MakeText(this.txtFullName, lx, y + lh, w); y += gap;

            MakeLabel(this.lblUsername, "USERNAME", lx, y);
            MakeText(this.txtUsername, lx, y + lh, w);
            MakeLabel(this.lblEmail, "EMAIL", rx, y - gap + gap);
            MakeText(this.txtEmail, rx, y + lh, w); y += gap;

            MakeLabel(this.lblRole, "ROLE", lx, y);
            this.cmbRole.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbRole.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.cmbRole.Items.AddRange(new object[] { "Admin", "Teacher", "Student" });
            this.cmbRole.SelectedIndex = 2;
            this.cmbRole.Size = new System.Drawing.Size(w, th);
            this.cmbRole.Location = new System.Drawing.Point(lx, y + lh);
            this.cmbRole.BackColor = System.Drawing.Color.FromArgb(245, 247, 255);
            this.cmbRole.FlatStyle = System.Windows.Forms.FlatStyle.Flat; y += gap;

            MakeLabel(this.lblPassword, "PASSWORD", lx, y);
            MakeText(this.txtPassword, lx, y + lh, w);
            this.txtPassword.UseSystemPasswordChar = true;
            MakeLabel(this.lblConfirm, "CONFIRM PASSWORD", rx, y);
            MakeText(this.txtConfirm, rx, y + lh, w);
            this.txtConfirm.UseSystemPasswordChar = true; y += gap;

            // btnRegister
            this.btnRegister.BackColor = System.Drawing.Color.FromArgb(30, 58, 138);
            this.btnRegister.FlatAppearance.BorderSize = 0;
            this.btnRegister.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnRegister.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Bold);
            this.btnRegister.ForeColor = System.Drawing.Color.White;
            this.btnRegister.Text = "✅  REGISTER";
            this.btnRegister.Size = new System.Drawing.Size(220, 42);
            this.btnRegister.Location = new System.Drawing.Point(lx, y + 10);
            this.btnRegister.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnRegister.Click += new System.EventHandler(this.btnRegister_Click);

            // btnCancel
            this.btnCancel.BackColor = System.Drawing.Color.FromArgb(239, 68, 68);
            this.btnCancel.FlatAppearance.BorderSize = 0;
            this.btnCancel.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCancel.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Bold);
            this.btnCancel.ForeColor = System.Drawing.Color.White;
            this.btnCancel.Text = "✖  CANCEL";
            this.btnCancel.Size = new System.Drawing.Size(180, 42);
            this.btnCancel.Location = new System.Drawing.Point(rx, y + 10);
            this.btnCancel.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);

            // Form
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(530, 430);
            this.Controls.Add(this.panelBody);
            this.Controls.Add(this.panelHeader);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Register New Account";
            this.BackColor = System.Drawing.Color.White;

            this.panelHeader.ResumeLayout(false);
            this.panelBody.ResumeLayout(false);
            this.ResumeLayout(false);
        }

        private void MakeLabel(System.Windows.Forms.Label lbl, string text, int x, int y)
        {
            lbl.AutoSize = false;
            lbl.Font = new System.Drawing.Font("Segoe UI", 8F, System.Drawing.FontStyle.Bold);
            lbl.ForeColor = System.Drawing.Color.FromArgb(80, 80, 110);
            lbl.Text = text;
            lbl.Size = new System.Drawing.Size(220, 18);
            lbl.Location = new System.Drawing.Point(x, y);
        }

        private void MakeText(System.Windows.Forms.TextBox txt, int x, int y, int w)
        {
            txt.Font = new System.Drawing.Font("Segoe UI", 10F);
            txt.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            txt.Size = new System.Drawing.Size(w, 30);
            txt.Location = new System.Drawing.Point(x, y);
            txt.BackColor = System.Drawing.Color.FromArgb(245, 247, 255);
        }

        private System.Windows.Forms.Panel panelHeader;
        private System.Windows.Forms.Panel panelBody;
        private System.Windows.Forms.Label lblTitle, lblSubtitle;
        private System.Windows.Forms.Label lblFullName, lblUsername, lblEmail, lblRole, lblPassword, lblConfirm;
        private System.Windows.Forms.TextBox txtFullName, txtUsername, txtEmail, txtPassword, txtConfirm;
        private System.Windows.Forms.ComboBox cmbRole;
        private System.Windows.Forms.Button btnRegister, btnCancel;
    }
}
