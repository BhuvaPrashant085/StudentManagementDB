namespace StudentMS
{
    partial class MarksForm
    {
        private System.ComponentModel.IContainer components = null;
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null)) components.Dispose();
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.panelHeader  = new System.Windows.Forms.Panel();
            this.lblTitle     = new System.Windows.Forms.Label();
            this.panelEntry   = new System.Windows.Forms.Panel();
            this.panelGrid    = new System.Windows.Forms.Panel();
            this.dgvMarks     = new System.Windows.Forms.DataGridView();
            this.txtSearch    = new System.Windows.Forms.TextBox();
            this.cmbStudent   = new System.Windows.Forms.ComboBox();
            this.txtCIA1      = new System.Windows.Forms.TextBox();
            this.txtCIA2      = new System.Windows.Forms.TextBox();
            this.txtCIA3      = new System.Windows.Forms.TextBox();
            this.btnSaveMarks = new System.Windows.Forms.Button();
            this.panelHeader.SuspendLayout();
            this.panelEntry.SuspendLayout();
            this.panelGrid.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvMarks)).BeginInit();
            this.SuspendLayout();

            // Header
            this.panelHeader.BackColor = System.Drawing.Color.FromArgb(5, 150, 105);
            this.panelHeader.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelHeader.Height = 55;
            this.panelHeader.Controls.Add(this.lblTitle);

            this.lblTitle.AutoSize = false;
            this.lblTitle.Font = new System.Drawing.Font("Segoe UI", 15F, System.Drawing.FontStyle.Bold);
            this.lblTitle.ForeColor = System.Drawing.Color.White;
            this.lblTitle.Text = "📊  CIA Marks Management";
            this.lblTitle.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblTitle.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lblTitle.Padding = new System.Windows.Forms.Padding(15, 0, 0, 0);

            // Entry Panel
            this.panelEntry.BackColor = System.Drawing.Color.White;
            this.panelEntry.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelEntry.Height = 120;
            this.panelEntry.Padding = new System.Windows.Forms.Padding(20, 10, 20, 10);
            this.panelEntry.Controls.Add(this.cmbStudent);
            this.panelEntry.Controls.Add(this.txtCIA1);
            this.panelEntry.Controls.Add(this.txtCIA2);
            this.panelEntry.Controls.Add(this.txtCIA3);
            this.panelEntry.Controls.Add(this.btnSaveMarks);

            var lblSel = MakeLbl("SELECT STUDENT", 20, 12);
            var lblC1  = MakeLbl("CIA 1 (Max 30)", 320, 12);
            var lblC2  = MakeLbl("CIA 2 (Max 30)", 460, 12);
            var lblC3  = MakeLbl("CIA 3 (Max 40)", 600, 12);
            this.panelEntry.Controls.Add(lblSel);
            this.panelEntry.Controls.Add(lblC1);
            this.panelEntry.Controls.Add(lblC2);
            this.panelEntry.Controls.Add(lblC3);

            this.cmbStudent.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.cmbStudent.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbStudent.Size = new System.Drawing.Size(270, 32);
            this.cmbStudent.Location = new System.Drawing.Point(20, 32);
            this.cmbStudent.SelectedIndexChanged += new System.EventHandler(this.cmbStudent_SelectedIndexChanged);

            MakeNumTxt(this.txtCIA1, 320, 32);
            MakeNumTxt(this.txtCIA2, 460, 32);
            MakeNumTxt(this.txtCIA3, 600, 32);

            this.btnSaveMarks.BackColor = System.Drawing.Color.FromArgb(5, 150, 105);
            this.btnSaveMarks.FlatAppearance.BorderSize = 0;
            this.btnSaveMarks.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSaveMarks.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold);
            this.btnSaveMarks.ForeColor = System.Drawing.Color.White;
            this.btnSaveMarks.Text = "💾 Save Marks";
            this.btnSaveMarks.Size = new System.Drawing.Size(140, 38);
            this.btnSaveMarks.Location = new System.Drawing.Point(760, 28);
            this.btnSaveMarks.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnSaveMarks.Click += new System.EventHandler(this.btnSaveMarks_Click);

            // Grid Panel
            this.panelGrid.BackColor = System.Drawing.Color.FromArgb(240, 244, 255);
            this.panelGrid.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelGrid.Padding = new System.Windows.Forms.Padding(15);
            this.panelGrid.Controls.Add(this.dgvMarks);
            this.panelGrid.Controls.Add(this.txtSearch);

            this.txtSearch.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.txtSearch.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtSearch.Size = new System.Drawing.Size(280, 32);
            this.txtSearch.Location = new System.Drawing.Point(15, 15);
            this.txtSearch.PlaceholderText = "🔍 Search by name or enrollment...";
            this.txtSearch.TextChanged += new System.EventHandler(this.txtSearch_TextChanged);

            this.dgvMarks.AllowUserToAddRows = false;
            this.dgvMarks.ReadOnly = true;
            this.dgvMarks.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvMarks.BackgroundColor = System.Drawing.Color.White;
            this.dgvMarks.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dgvMarks.RowHeadersVisible = false;
            this.dgvMarks.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvMarks.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.dgvMarks.ColumnHeadersDefaultCellStyle.BackColor = System.Drawing.Color.FromArgb(5, 150, 105);
            this.dgvMarks.ColumnHeadersDefaultCellStyle.ForeColor = System.Drawing.Color.White;
            this.dgvMarks.ColumnHeadersDefaultCellStyle.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.dgvMarks.ColumnHeadersHeight = 35;
            this.dgvMarks.RowTemplate.Height = 28;
            this.dgvMarks.AlternatingRowsDefaultCellStyle.BackColor = System.Drawing.Color.FromArgb(236, 253, 245);
            this.dgvMarks.Size = new System.Drawing.Size(960, 400);
            this.dgvMarks.Location = new System.Drawing.Point(15, 58);

            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1000, 620);
            this.Controls.Add(this.panelGrid);
            this.Controls.Add(this.panelEntry);
            this.Controls.Add(this.panelHeader);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "CIA Marks Management";
            this.Load += new System.EventHandler(this.MarksForm_Load);

            this.panelHeader.ResumeLayout(false);
            this.panelEntry.ResumeLayout(false);
            this.panelGrid.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvMarks)).EndInit();
            this.ResumeLayout(false);
        }

        private System.Windows.Forms.Label MakeLbl(string text, int x, int y)
        {
            var l = new System.Windows.Forms.Label();
            l.AutoSize = false;
            l.Font = new System.Drawing.Font("Segoe UI", 8F, System.Drawing.FontStyle.Bold);
            l.ForeColor = System.Drawing.Color.FromArgb(80, 80, 110);
            l.Text = text;
            l.Size = new System.Drawing.Size(130, 18);
            l.Location = new System.Drawing.Point(x, y);
            return l;
        }

        private void MakeNumTxt(System.Windows.Forms.TextBox t, int x, int y)
        {
            t.Font = new System.Drawing.Font("Segoe UI", 11F);
            t.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            t.Size = new System.Drawing.Size(100, 32);
            t.Location = new System.Drawing.Point(x, y);
            t.BackColor = System.Drawing.Color.FromArgb(245, 247, 255);
            t.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
        }

        private System.Windows.Forms.Panel panelHeader, panelEntry, panelGrid;
        private System.Windows.Forms.Label lblTitle;
        private System.Windows.Forms.DataGridView dgvMarks;
        private System.Windows.Forms.TextBox txtSearch, txtCIA1, txtCIA2, txtCIA3;
        private System.Windows.Forms.ComboBox cmbStudent;
        private System.Windows.Forms.Button btnSaveMarks;
    }
}
