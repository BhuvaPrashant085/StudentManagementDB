namespace StudentMS
{
    partial class DashboardForm
    {
        private System.ComponentModel.IContainer components = null;
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null)) components.Dispose();
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.panelSidebar  = new System.Windows.Forms.Panel();
            this.panelContent  = new System.Windows.Forms.Panel();
            this.panelTopBar   = new System.Windows.Forms.Panel();
            this.lblPageTitle  = new System.Windows.Forms.Label();
            this.lblUserName   = new System.Windows.Forms.Label();
            this.lblRole       = new System.Windows.Forms.Label();
            this.btnLogout     = new System.Windows.Forms.Button();
            // Sidebar items
            this.lblSideTitle  = new System.Windows.Forms.Label();
            this.btnStudents   = new System.Windows.Forms.Button();
            this.btnMarks      = new System.Windows.Forms.Button();
            this.btnLeaderboard= new System.Windows.Forms.Button();
            // Stat cards
            this.panelCard1    = new System.Windows.Forms.Panel();
            this.panelCard2    = new System.Windows.Forms.Panel();
            this.panelCard3    = new System.Windows.Forms.Panel();
            this.panelCard4    = new System.Windows.Forms.Panel();
            this.lblTotalStudents = new System.Windows.Forms.Label();
            this.lblTotalMarks    = new System.Windows.Forms.Label();
            this.lblAvgMarks      = new System.Windows.Forms.Label();
            this.lblTopStudent    = new System.Windows.Forms.Label();
            this.panelSidebar.SuspendLayout();
            this.panelContent.SuspendLayout();
            this.panelTopBar.SuspendLayout();
            this.SuspendLayout();

            // ── SIDEBAR ────────────────────────────────────────────
            this.panelSidebar.BackColor = System.Drawing.Color.FromArgb(15, 23, 42);
            this.panelSidebar.Dock = System.Windows.Forms.DockStyle.Left;
            this.panelSidebar.Width = 220;
            this.panelSidebar.Controls.Add(this.lblSideTitle);
            this.panelSidebar.Controls.Add(this.btnStudents);
            this.panelSidebar.Controls.Add(this.btnMarks);
            this.panelSidebar.Controls.Add(this.btnLeaderboard);

            this.lblSideTitle.AutoSize = false;
            this.lblSideTitle.Font = new System.Drawing.Font("Segoe UI", 14F, System.Drawing.FontStyle.Bold);
            this.lblSideTitle.ForeColor = System.Drawing.Color.White;
            this.lblSideTitle.Text = "🎓 StudentMS";
            this.lblSideTitle.Size = new System.Drawing.Size(220, 70);
            this.lblSideTitle.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblSideTitle.Location = new System.Drawing.Point(0, 0);
            this.lblSideTitle.BackColor = System.Drawing.Color.FromArgb(30, 58, 138);

            MakeSideBtn(this.btnStudents,    "👥   Manage Students",  90,  this.btnStudents_Click);
            MakeSideBtn(this.btnMarks,       "📊   CIA Marks",        150, this.btnMarks_Click);
            MakeSideBtn(this.btnLeaderboard, "🏆   Leaderboard",      210, this.btnLeaderboard_Click);

            // ── TOP BAR ────────────────────────────────────────────
            this.panelTopBar.BackColor = System.Drawing.Color.White;
            this.panelTopBar.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelTopBar.Height = 60;
            this.panelTopBar.Controls.Add(this.lblPageTitle);
            this.panelTopBar.Controls.Add(this.lblUserName);
            this.panelTopBar.Controls.Add(this.lblRole);
            this.panelTopBar.Controls.Add(this.btnLogout);

            this.lblPageTitle.AutoSize = false;
            this.lblPageTitle.Font = new System.Drawing.Font("Segoe UI", 16F, System.Drawing.FontStyle.Bold);
            this.lblPageTitle.ForeColor = System.Drawing.Color.FromArgb(30, 58, 138);
            this.lblPageTitle.Text = "Dashboard";
            this.lblPageTitle.Size = new System.Drawing.Size(300, 60);
            this.lblPageTitle.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lblPageTitle.Location = new System.Drawing.Point(20, 0);

            this.lblUserName.AutoSize = false;
            this.lblUserName.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold);
            this.lblUserName.ForeColor = System.Drawing.Color.FromArgb(30, 58, 138);
            this.lblUserName.Text = "👤 User";
            this.lblUserName.Size = new System.Drawing.Size(250, 30);
            this.lblUserName.TextAlign = System.Drawing.ContentAlignment.BottomRight;
            this.lblUserName.Location = new System.Drawing.Point(430, 5);

            this.lblRole.AutoSize = false;
            this.lblRole.Font = new System.Drawing.Font("Segoe UI", 8F);
            this.lblRole.ForeColor = System.Drawing.Color.Gray;
            this.lblRole.Text = "Admin";
            this.lblRole.Size = new System.Drawing.Size(250, 20);
            this.lblRole.TextAlign = System.Drawing.ContentAlignment.TopRight;
            this.lblRole.Location = new System.Drawing.Point(430, 37);

            this.btnLogout.BackColor = System.Drawing.Color.FromArgb(239, 68, 68);
            this.btnLogout.FlatAppearance.BorderSize = 0;
            this.btnLogout.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnLogout.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.btnLogout.ForeColor = System.Drawing.Color.White;
            this.btnLogout.Text = "Logout";
            this.btnLogout.Size = new System.Drawing.Size(80, 32);
            this.btnLogout.Location = new System.Drawing.Point(700, 14);
            this.btnLogout.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnLogout.Click += new System.EventHandler(this.btnLogout_Click);

            // ── CONTENT ────────────────────────────────────────────
            this.panelContent.BackColor = System.Drawing.Color.FromArgb(240, 244, 255);
            this.panelContent.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelContent.Controls.Add(this.panelCard4);
            this.panelContent.Controls.Add(this.panelCard3);
            this.panelContent.Controls.Add(this.panelCard2);
            this.panelContent.Controls.Add(this.panelCard1);
            this.panelContent.Controls.Add(this.panelTopBar);

            // ── STAT CARDS ─────────────────────────────────────────
            MakeCard(this.panelCard1, this.lblTotalStudents, "👥 Total Students", "0",
                System.Drawing.Color.FromArgb(30, 58, 138), 20, 80);
            MakeCard(this.panelCard2, this.lblTotalMarks, "📊 Marks Entered", "0",
                System.Drawing.Color.FromArgb(5, 150, 105), 220, 80);
            MakeCard(this.panelCard3, this.lblAvgMarks, "📈 Average CIA", "0.0",
                System.Drawing.Color.FromArgb(180, 83, 9), 420, 80);
            MakeCard(this.panelCard4, this.lblTopStudent, "🏆 Top Student", "—",
                System.Drawing.Color.FromArgb(109, 40, 217), 620, 80);

            // ── FORM ───────────────────────────────────────────────
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1050, 600);
            this.Controls.Add(this.panelContent);
            this.Controls.Add(this.panelSidebar);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.Name = "DashboardForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Student Management System - Dashboard";
            this.Load += new System.EventHandler(this.DashboardForm_Load);
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.DashboardForm_FormClosing);

            this.panelSidebar.ResumeLayout(false);
            this.panelContent.ResumeLayout(false);
            this.panelTopBar.ResumeLayout(false);
            this.ResumeLayout(false);
        }

        private void MakeSideBtn(System.Windows.Forms.Button btn, string text, int y, System.EventHandler handler)
        {
            btn.BackColor = System.Drawing.Color.Transparent;
            btn.FlatAppearance.BorderSize = 0;
            btn.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(30, 58, 138);
            btn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            btn.Font = new System.Drawing.Font("Segoe UI", 10F);
            btn.ForeColor = System.Drawing.Color.FromArgb(180, 210, 255);
            btn.Text = text;
            btn.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            btn.Padding = new System.Windows.Forms.Padding(15, 0, 0, 0);
            btn.Size = new System.Drawing.Size(220, 46);
            btn.Location = new System.Drawing.Point(0, y);
            btn.Cursor = System.Windows.Forms.Cursors.Hand;
            btn.Click += handler;
        }

        private void MakeCard(System.Windows.Forms.Panel panel, System.Windows.Forms.Label lbl,
            string title, string val, System.Drawing.Color color, int x, int y)
        {
            panel.BackColor = color;
            panel.Size = new System.Drawing.Size(170, 110);
            panel.Location = new System.Drawing.Point(x, y);

            var lblTitle = new System.Windows.Forms.Label();
            lblTitle.AutoSize = false;
            lblTitle.Font = new System.Drawing.Font("Segoe UI", 8F);
            lblTitle.ForeColor = System.Drawing.Color.FromArgb(200, 230, 255);
            lblTitle.Text = title;
            lblTitle.Size = new System.Drawing.Size(150, 30);
            lblTitle.Location = new System.Drawing.Point(10, 10);
            lblTitle.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;

            lbl.AutoSize = false;
            lbl.Font = new System.Drawing.Font("Segoe UI", 24F, System.Drawing.FontStyle.Bold);
            lbl.ForeColor = System.Drawing.Color.White;
            lbl.Text = val;
            lbl.Size = new System.Drawing.Size(150, 60);
            lbl.Location = new System.Drawing.Point(10, 42);
            lbl.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;

            panel.Controls.Add(lblTitle);
            panel.Controls.Add(lbl);
        }

        private System.Windows.Forms.Panel panelSidebar, panelContent, panelTopBar;
        private System.Windows.Forms.Panel panelCard1, panelCard2, panelCard3, panelCard4;
        private System.Windows.Forms.Label lblSideTitle, lblPageTitle, lblUserName, lblRole;
        private System.Windows.Forms.Label lblTotalStudents, lblTotalMarks, lblAvgMarks, lblTopStudent;
        private System.Windows.Forms.Button btnStudents, btnMarks, btnLeaderboard, btnLogout;
    }
}
