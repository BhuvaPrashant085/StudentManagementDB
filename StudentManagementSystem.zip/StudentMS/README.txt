=====================================================
  STUDENT MANAGEMENT SYSTEM - Setup Instructions
=====================================================

PROJECT: Student Management System
FRAMEWORK: .NET Framework 4.7.2 (Windows Forms)
DATABASE: SQL Server (LocalDB / SQLEXPRESS)

=====================================================
  STEP 1: Setup Database
=====================================================
1. Open SQL Server Management Studio (SSMS)
2. Connect to your SQL Server instance
3. Open the file: StudentManagementDB.sql
4. Press F5 to execute the entire script
5. This creates:
   - Database: StudentManagementDB
   - Tables: Users, Students, CIAMarks
   - View: View_Leaderboard
   - Trigger: trg_InsertCIAMarks
   - Sample data with 10 students

DEFAULT LOGIN CREDENTIALS:
   Username: admin      Password: admin123
   Username: teacher    Password: teacher123

=====================================================
  STEP 2: Configure Connection String
=====================================================
Open App.config and check the connection string:

  Data Source=.\SQLEXPRESS;Initial Catalog=StudentManagementDB;Integrated Security=True

Change ".\SQLEXPRESS" to your SQL Server instance name.
Common options:
  - .\SQLEXPRESS         (SQL Server Express)
  - (localdb)\MSSQLLocalDB  (LocalDB)
  - .\SQLSERVER          (Full SQL Server)
  - localhost            (Default instance)

=====================================================
  STEP 3: Open & Run the Project
=====================================================
1. Open Visual Studio 2019 or 2022
2. File > Open > Project/Solution
3. Select: DOTNET.sln
4. Press F5 to Build and Run

=====================================================
  FEATURES
=====================================================
✅ Login / Register
✅ Dashboard with KPI cards (Students, Marks, Avg, Pass)
✅ Student Management (Add / Edit / Delete / Search)
✅ CIA Marks Management (CIA1 + CIA2 + CIA3 per subject)
✅ Auto Grade Calculation (O / A+ / A / B+ / B / C / P / F)
✅ Leaderboard (ranked with Gold/Silver/Bronze highlights)

=====================================================
  GRADE SCALE (out of 150)
=====================================================
  O  (Outstanding)  : 135 - 150
  A+ (Excellent)    : 120 - 134
  A  (Very Good)    : 105 - 119
  B+ (Good)         :  90 - 104
  B  (Above Average):  75 -  89
  C  (Average)      :  60 -  74
  P  (Pass)         :  50 -  59
  F  (Fail)         :   0 -  49

=====================================================
