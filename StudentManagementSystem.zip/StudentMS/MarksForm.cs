using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace StudentMS
{
    public partial class MarksForm : Form
    {
        public MarksForm() { InitializeComponent(); }

        private void MarksForm_Load(object sender, EventArgs e)
        {
            LoadStudentsDropdown();
            LoadMarks();
        }

        private void LoadStudentsDropdown()
        {
            DataTable dt = DBHelper.ExecuteQuery("SELECT StudentID, StudentName + ' (' + EnrollmentNo + ')' AS Display FROM Students ORDER BY StudentName");
            cmbStudent.DataSource = dt;
            cmbStudent.DisplayMember = "Display";
            cmbStudent.ValueMember = "StudentID";
            cmbStudent.SelectedIndex = -1;
        }

        private void LoadMarks(string search = "")
        {
            string query = @"SELECT m.MarkID, s.EnrollmentNo, s.StudentName, s.Branch, s.Semester,
                                    m.CIA1, m.CIA2, m.CIA3,
                                    ISNULL(m.CIA1,0)+ISNULL(m.CIA2,0)+ISNULL(m.CIA3,0) AS Total,
                                    CAST((ISNULL(m.CIA1,0)+ISNULL(m.CIA2,0)+ISNULL(m.CIA3,0))/3.0 AS DECIMAL(5,1)) AS Average
                             FROM CIAMarks m
                             JOIN Students s ON m.StudentID = s.StudentID";
            if (!string.IsNullOrEmpty(search))
                query += " WHERE s.StudentName LIKE @s OR s.EnrollmentNo LIKE @s";
            query += " ORDER BY s.StudentName";

            SqlParameter[] p = string.IsNullOrEmpty(search) ? null :
                new[] { new SqlParameter("@s", "%" + search + "%") };

            dgvMarks.DataSource = DBHelper.ExecuteQuery(query, p);
        }

        private void btnSaveMarks_Click(object sender, EventArgs e)
        {
            if (cmbStudent.SelectedIndex < 0)
            { MessageBox.Show("Please select a student.", "Validation", MessageBoxButtons.OK, MessageBoxIcon.Warning); return; }

            int studentId = Convert.ToInt32(cmbStudent.SelectedValue);

            if (!decimal.TryParse(txtCIA1.Text, out decimal c1) || c1 < 0 || c1 > 30)
            { MessageBox.Show("CIA 1 must be 0–30.", "Validation", MessageBoxButtons.OK, MessageBoxIcon.Warning); return; }
            if (!decimal.TryParse(txtCIA2.Text, out decimal c2) || c2 < 0 || c2 > 30)
            { MessageBox.Show("CIA 2 must be 0–30.", "Validation", MessageBoxButtons.OK, MessageBoxIcon.Warning); return; }
            if (!decimal.TryParse(txtCIA3.Text, out decimal c3) || c3 < 0 || c3 > 40)
            { MessageBox.Show("CIA 3 must be 0–40.", "Validation", MessageBoxButtons.OK, MessageBoxIcon.Warning); return; }

            object exists = DBHelper.ExecuteScalar("SELECT COUNT(*) FROM CIAMarks WHERE StudentID=@id",
                new[] { new SqlParameter("@id", studentId) });

            if (Convert.ToInt32(exists) > 0)
            {
                DBHelper.ExecuteNonQuery(
                    "UPDATE CIAMarks SET CIA1=@c1, CIA2=@c2, CIA3=@c3 WHERE StudentID=@id",
                    new[] { new SqlParameter("@c1",c1), new SqlParameter("@c2",c2),
                            new SqlParameter("@c3",c3), new SqlParameter("@id",studentId) });
            }
            else
            {
                DBHelper.ExecuteNonQuery(
                    "INSERT INTO CIAMarks (StudentID, CIA1, CIA2, CIA3) VALUES (@id,@c1,@c2,@c3)",
                    new[] { new SqlParameter("@id",studentId), new SqlParameter("@c1",c1),
                            new SqlParameter("@c2",c2), new SqlParameter("@c3",c3) });
            }

            MessageBox.Show("✅ Marks saved successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
            txtCIA1.Clear(); txtCIA2.Clear(); txtCIA3.Clear();
            cmbStudent.SelectedIndex = -1;
            LoadMarks();
        }

        private void cmbStudent_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cmbStudent.SelectedIndex < 0) return;
            int sid = Convert.ToInt32(cmbStudent.SelectedValue);
            DataTable dt = DBHelper.ExecuteQuery("SELECT CIA1,CIA2,CIA3 FROM CIAMarks WHERE StudentID=@id",
                new[] { new SqlParameter("@id", sid) });
            if (dt.Rows.Count > 0)
            {
                txtCIA1.Text = dt.Rows[0]["CIA1"]?.ToString() ?? "";
                txtCIA2.Text = dt.Rows[0]["CIA2"]?.ToString() ?? "";
                txtCIA3.Text = dt.Rows[0]["CIA3"]?.ToString() ?? "";
            }
            else { txtCIA1.Clear(); txtCIA2.Clear(); txtCIA3.Clear(); }
        }

        private void txtSearch_TextChanged(object sender, EventArgs e) => LoadMarks(txtSearch.Text.Trim());
    }
}
